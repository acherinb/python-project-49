# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Brain games\n\nThis repository is made by Andrey Cheredinov, a student of Hexlet educational project.\n\n### Requirements\nPython 3.10 or above\n\n### Installation\nUse following commands for installing:\n\n\tpoetry install\n\tpoetry build\n\tpoetry publish\n\tpython3 -m pip install dist/*.whl\n\n===========================================================================\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/acherinb/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/acherinb/python-project-49/actions)\n\n### asciinema\n\n#### brain-even [![asciicast](https://asciinema.org/a/DvkZpuI0YWGBQqZUG4VVTAXku.png)](https://asciinema.org/a/DvkZpuI0YWGBQqZUG4VVTAXku)\n\n#### brain-calc [![asciicast](https://asciinema.org/a/JHLp9bmsti1t0K5e2Mx1NBUA2.png)](https://asciinema.org/a/JHLp9bmsti1t0K5e2Mx1NBUA2)\n\n### brain-gcd [![asciicast](https://asciinema.org/a/dEJfFdyxCRDHt6FwLt9P0CL1K.png)](https://asciinema.org/a/dEJfFdyxCRDHt6FwLt9P0CL1K)\n\n### brain-progression [![asciicast](https://asciinema.org/a/0YQWXsDjZSinG6mDAsY9O7ZkG.png)](https://asciinema.org/a/0YQWXsDjZSinG6mDAsY9O7ZkG)\n',
    'author': 'acher',
    'author_email': 'acher@inbox.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
